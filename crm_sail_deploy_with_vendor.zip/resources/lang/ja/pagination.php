<?php

return [
    'previous' => '&laquo; 前へ',
    'next' => '次へ &raquo;',
    'showing' => ':first 〜 :last 件目を表示（全 :total 件）',
];
