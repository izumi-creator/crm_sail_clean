<?php

return [
    'failed' => 'ユーザーIDまたはパスワードが正しくありません。',
    'throttle' => 'ログイン試行が多すぎます。 :seconds 秒後にお試しください。',
];
