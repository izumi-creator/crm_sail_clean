@extends('layouts.app')

@section('content')
<div class="consultation mx-auto max-w-4xl">
    <h2 class="text-xl font-bold mb-4">会計一覧</h2>
    <p>ここに会計データが表示される予定です。</p>
</div>
@endsection