<!-- resources/views/layouts/footer.blade.php -->
<footer>
    <hr>
    <p>&copy; 2025 My Laravel App</p>
</footer>