<!-- resources/views/layouts/header.blade.php -->
<header>
    <h1>My Laravel App</h1>
    <nav>
        <a href="/users">Users</a> | 
        <a href="/user/taro">User Taro</a>
    </nav>
    <hr>
</header>